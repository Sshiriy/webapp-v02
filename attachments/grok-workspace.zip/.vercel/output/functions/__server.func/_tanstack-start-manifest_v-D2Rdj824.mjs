//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D2Rdj824.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/companion",
			"/file",
			"/learn",
			"/scope",
			"/support",
			"/track",
			"/visit"
		],
		preloads: ["/assets/index-LFlGiAcq.js", "/assets/react-DB-4Zxce.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-LFlGiAcq.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-TRPSTOcU.js", "/assets/flags-7Ul808n-.js"]
	},
	"/companion": {
		filePath: "/workspace/src/routes/companion.tsx",
		children: void 0,
		preloads: ["/assets/companion-D-1t3Yso.js", "/assets/flags-7Ul808n-.js"]
	},
	"/file": {
		filePath: "/workspace/src/routes/file.tsx",
		children: void 0,
		preloads: ["/assets/file-CuHP79K5.js"]
	},
	"/learn": {
		filePath: "/workspace/src/routes/learn.tsx",
		children: ["/learn/$slug"],
		preloads: ["/assets/learn-DlNuqmXs.js"]
	},
	"/scope": {
		filePath: "/workspace/src/routes/scope.tsx",
		children: void 0,
		preloads: ["/assets/scope-BbgY2Y2M.js"]
	},
	"/support": {
		filePath: "/workspace/src/routes/support.tsx",
		children: void 0,
		preloads: ["/assets/support-C0cCJAdw.js"]
	},
	"/track": {
		filePath: "/workspace/src/routes/track.tsx",
		children: void 0,
		preloads: ["/assets/track-yTH437Br.js", "/assets/flags-7Ul808n-.js"]
	},
	"/visit": {
		filePath: "/workspace/src/routes/visit.tsx",
		children: void 0,
		preloads: ["/assets/visit-BxeaXGy6.js"]
	},
	"/learn/$slug": {
		filePath: "/workspace/src/routes/learn.$slug.tsx",
		children: void 0,
		preloads: ["/assets/learn._slug-KZQI7tXH.js"]
	}
} });
//#endregion
export { tsrStartManifest };
