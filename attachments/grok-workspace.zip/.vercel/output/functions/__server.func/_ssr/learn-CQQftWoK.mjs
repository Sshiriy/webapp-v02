import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as PageIntro, i as articles } from "./router-CElB2d5Z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learn-CQQftWoK.js
var import_jsx_runtime = require_jsx_runtime();
function Learn() {
	const cancers = articles.filter((article) => article.kind === "cancer");
	const guides = articles.filter((article) => article.kind === "guide");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
				kicker: "آموزش",
				title: "آنچه بین تشخیص و تصمیم، ارزش دانستن دارد.",
				lede: "متن‌ها عمومی و محافظه‌کارند. برنامهٔ واقعی درمان را فقط تیم بیمارستان آیت‌الله رئیسی برای شما می‌نویسد. دستورالعمل‌های دارای مجوز، از جمله NCCN، اینجا بازنشر نشده‌اند."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-semibold text-copper",
				children: "راهنماهای مشترک"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 grid gap-3 sm:grid-cols-2",
				children: guides.map((article) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/learn/$slug",
					params: { slug: article.slug },
					className: "block h-full rounded-card border border-line bg-surface p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-lg font-bold",
						children: article.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-6 text-muted",
						children: article.summary
					})]
				}) }, article.slug))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-semibold text-copper",
				children: "به تفکیک نوع"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 grid gap-3 sm:grid-cols-2",
				children: cancers.map((article) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/learn/$slug",
					params: { slug: article.slug },
					className: "block h-full rounded-card border border-line bg-paper p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: article.kicker
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-1 text-lg font-bold",
							children: article.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-6 text-muted",
							children: article.summary
						})
					]
				}) }, article.slug))
			})] })
		]
	});
}
//#endregion
export { Learn as component };
