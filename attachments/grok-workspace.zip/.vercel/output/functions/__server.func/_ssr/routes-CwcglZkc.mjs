import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as latestAssessment, r as trendNote } from "./flags-BEUhCsFE.mjs";
import { c as BookOpen, l as ArrowLeft, r as ShieldCheck, s as ClipboardList } from "../_libs/lucide-react.mjs";
import { _ as useCare, b as Disclaimer, g as upcomingCheckups, m as safeTel, o as cancerLabel, p as relativeDay, r as LevelChip, u as formatFa, y as Card } from "./router-CElB2d5Z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CwcglZkc.js
var import_jsx_runtime = require_jsx_runtime();
var paths = [
	{
		title: "آموزش",
		text: "شش سرطان شایع طرح، به علاوهٔ واژه‌نامهٔ درمان و تب.",
		to: "/learn"
	},
	{
		title: "پیگیری",
		text: "درد، خستگی، تب و تقویم آزمایش و تزریق.",
		to: "/track"
	},
	{
		title: "حمایت",
		text: "مسیر مددکاری و حمایت روانی، بدون شمارهٔ ساختگی.",
		to: "/support"
	}
];
function Home() {
	if (!useCare((state) => state.profile).onboarded) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landing, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, {});
}
function Landing() {
	const loadDemo = useCare((state) => state.loadDemo);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Disclaimer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid items-end gap-8 lg:grid-cols-[1.4fr_0.8fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-copper",
						children: "مرکز رشد فناوری سلامت · نسخهٔ اول"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 max-w-xl text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl",
						children: "همراه درمان، برای روزهایی که بین دو ویزیت می‌گذرد."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-lg leading-8 text-muted",
						children: "همدم برای بیماران بیمارستان آیت‌الله رئیسی ساخته شده تا آموزش درمان، دفتر حال، نوبت‌ها و سؤال‌های پیش از ویزیت یک‌جا بماند. تشخیص نمی‌دهد و جواب آزمایش را تفسیر نمی‌کند."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/file",
							className: "inline-flex min-h-11 items-center rounded-xl bg-cypress px-4 text-sm font-semibold text-paper",
							children: "ساخت پرونده روی این دستگاه"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: loadDemo,
							className: "inline-flex min-h-11 items-center rounded-xl border border-line bg-surface px-4 text-sm font-semibold",
							children: "دیدن با نمونهٔ نمایشی"
						})]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "bg-cypress text-paper",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-foam",
						children: "امروز چه کار می‌کند"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-4 grid gap-3 text-sm leading-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "آموزش محافظه‌کارانه دربارهٔ مسیر درمان، نه کپی دستورالعمل‌های دارای مجوز." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "ثبت حال و قاعدهٔ شفاف «کی زنگ بزنید»؛ دلیلش را هم نشان می‌دهد." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "فرم پیش از ویزیت که می‌شود برای پزشک خواند." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "همراه هوشمند آموزشی، با ممنوعیت صریح تشخیص." })
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "grid gap-3 sm:grid-cols-3",
				children: paths.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: item.to,
					className: "rounded-card border border-line bg-surface p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-bold",
						children: item.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-6 text-muted",
						children: item.text
					})]
				}, item.to))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex flex-col gap-3 sm:flex-row sm:items-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
						className: "size-6 shrink-0 text-cypress",
						strokeWidth: 1.75
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-7 text-muted",
						children: "شبکهٔ عصبی تشخیص سرطان، پیش‌بینی متاستاز و اتصال هولتر در این نسخه عمداً نیست. دلیل بالینی‌اش را در محدودهٔ نسخه بخوانید."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/scope",
						className: "text-sm font-semibold text-cypress sm:ms-auto",
						children: "محدودهٔ نسخه"
					})
				]
			})
		]
	});
}
function Dashboard() {
	const profile = useCare((state) => state.profile);
	const symptoms = useCare((state) => state.symptoms);
	const checkups = useCare((state) => state.checkups);
	const clearAll = useCare((state) => state.clearAll);
	const assessment = latestAssessment(symptoms);
	const trend = trendNote(symptoms);
	const next = upcomingCheckups(checkups)[0];
	const tel = safeTel(profile.clinicPhone);
	const latest = [...symptoms].sort((a, b) => b.date.localeCompare(a.date))[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Disclaimer, {}),
			profile.demo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm leading-6 text-copper",
				children: [
					"این پرونده نمونهٔ نمایشی و ساختگی است.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: clearAll,
						className: "font-semibold underline",
						children: "پاک کردن و شروع واقعی"
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-[1.3fr_0.7fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "پروندهٔ این دستگاه"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-1 text-3xl font-extrabold tracking-tight",
								children: profile.name || "بدون نام"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm text-muted",
								children: [
									cancerLabel(profile),
									profile.city ? ` · ${profile.city}` : "",
									profile.doctor ? ` · ${profile.doctor}` : ""
								]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelChip, { level: assessment.level })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-6 text-xl font-bold",
						children: assessment.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 grid gap-2 text-sm leading-6 text-muted",
						children: assessment.reasons.map((reason) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: reason }, reason))
					}),
					trend ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm font-medium text-cypress",
						children: trend
					}) : null,
					assessment.level === "urgent" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: tel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: tel,
							className: "inline-flex min-h-11 items-center rounded-xl bg-copper px-4 text-sm font-semibold text-paper",
							children: "تماس با شماره‌ای که خودتان ذخیره کرده‌اید"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/file",
							className: "text-sm font-semibold text-copper",
							children: "شمارهٔ درمانگاه را در پرونده بنویسید تا دکمهٔ تماس فعال شود"
						})
					}) : null
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "flex flex-col",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "نوبت پیش رو"
						}),
						next ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-2xl font-extrabold tabular-nums",
								children: relativeDay(next.date)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-medium",
								children: next.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [formatFa(next.date), next.place ? ` · ${next.place}` : ""]
							})
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 leading-7 text-muted",
							children: "نوبت آینده‌ای در تقویم نیست."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/track",
							className: "mt-auto pt-4 text-sm font-semibold text-cypress",
							children: "دفتر پیگیری"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/track",
						className: "rounded-card border border-line bg-surface p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, {
								className: "size-5 text-cypress",
								strokeWidth: 1.75
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-bold",
								children: "ثبت حال امروز"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: latest ? `آخرین ثبت ${formatFa(latest.date)}` : "هنوز ثبتی نیست"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/visit",
						className: "rounded-card border border-line bg-surface p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, {
								className: "size-5 text-cypress",
								strokeWidth: 1.75
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-bold",
								children: "پیش از ویزیت"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "سؤال‌ها را قبل از اتاق پزشک بنویسید."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/companion",
						className: "rounded-card border border-line bg-surface p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
								className: "size-5 text-cypress",
								strokeWidth: 1.75
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-bold",
								children: "پرسش آموزشی"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "توضیح واژهٔ درمان، نه نظر تشخیصی."
							})
						]
					})
				]
			})
		]
	});
}
//#endregion
export { Home as component };
