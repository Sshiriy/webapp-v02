import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as latestAssessment } from "./flags-BEUhCsFE.mjs";
import { a as object, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
import { S as PageIntro, _ as useCare, b as Disclaimer, g as upcomingCheckups, o as cancerLabel, u as formatFa, v as Button, w as TextArea } from "./router-CElB2d5Z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/companion-BGd97MIP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var Input = object({
	message: string().trim().min(1).max(1200),
	history: array(object({
		role: _enum(["user", "assistant"]),
		text: string().max(2e3)
	})).max(8),
	context: string().max(1800)
});
var askCompanion = createServerFn({ method: "POST" }).validator((input) => Input.parse(input)).handler(createSsrRpc("a016544ba5b241b509748ab44f2231efc7fa2cf98f3347b3b352ad38313b8c10"));
var suggestions = [
	"شیمی‌درمانی را ساده و بدون توصیهٔ دارویی توضیح بده.",
	"تب در طول درمان را چطور برای بخش توضیح دهم؟",
	"سر ویزیت انکولوژی چه سؤال‌هایی فراموش می‌شود؟",
	"حال این هفته‌ام را برای پزشک در پنج خط خلاصه کن، بدون تشخیص."
];
function CompanionPage() {
	const profile = useCare((state) => state.profile);
	const symptoms = useCare((state) => state.symptoms);
	const checkups = useCare((state) => state.checkups);
	const visit = useCare((state) => state.visit);
	const chat = useCare((state) => state.chat);
	const addChat = useCare((state) => state.addChat);
	const clearChat = useCare((state) => state.clearChat);
	const [message, setMessage] = (0, import_react.useState)("");
	const [attach, setAttach] = (0, import_react.useState)(true);
	const [pending, setPending] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	async function send(text) {
		const trimmed = text.trim();
		if (!trimmed || pending) return;
		setPending(true);
		setError(null);
		setMessage("");
		addChat({
			role: "user",
			text: trimmed
		});
		const history = chat.slice(-6).map((turn) => ({
			role: turn.role,
			text: turn.text
		}));
		try {
			const result = await askCompanion({ data: {
				message: trimmed,
				history,
				context: attach ? buildContext() : "کاربر نخواسته زمینهٔ پرونده پیوست شود."
			} });
			if (!result.ok) {
				setError(result.error);
				return;
			}
			addChat({
				role: "assistant",
				text: result.text
			});
		} catch {
			setError("پرسش فرستاده نشد. دوباره تلاش کنید، یا سؤال را برای پزشک بنویسید.");
		} finally {
			setPending(false);
		}
	}
	function buildContext() {
		const assessment = latestAssessment(symptoms);
		const next = upcomingCheckups(checkups)[0];
		const latest = [...symptoms].sort((a, b) => b.date.localeCompare(a.date))[0];
		return [
			profile.demo ? "این پرونده نمونهٔ نمایشی و ساختگی است." : "پروندهٔ محلی کاربر.",
			profile.onboarded ? `نام: ${profile.name || "ناگفته"}. نوع ثبت‌شده: ${cancerLabel(profile)}.` : "پرونده کامل نشده.",
			`جمع‌بندی قاعدهٔ هشدار روی آخرین ثبت: ${assessment.title}`,
			latest ? `آخرین حال ${formatFa(latest.date)}: درد ${latest.pain}، خستگی ${latest.fatigue}، تهوع ${latest.nausea}. یادداشت: ${latest.note || "ندارد"}` : "حال ثبت نشده.",
			next ? `نوبت بعدی: ${next.title} در ${formatFa(next.date)}` : "نوبت آینده ثبت نشده.",
			visit.questions ? `سؤال‌های پیش‌ویزیت: ${visit.questions}` : ""
		].filter(Boolean).join("\n");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-2xl gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
				kicker: "همراه هوشمند",
				title: "سؤال آموزشی بپرسید، نه تشخیص.",
				lede: "پاسخ را مدل زبانی می‌دهد و ممکن است اشتباه کند. اگر علامت فوری دارید، به‌جای چت با بخش یا اورژانس تماس بگیرید."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Disclaimer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex min-h-11 items-center gap-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: attach,
					onChange: (event) => setAttach(event.target.checked),
					className: "size-4 accent-cypress"
				}), "خلاصهٔ پروندهٔ همین دستگاه به سؤال پیوست شود"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: suggestions.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: pending,
					onClick: () => void send(item),
					className: "rounded-full border border-line bg-surface px-3 py-2 text-start text-sm leading-6",
					children: item
				}, item))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "grid gap-4",
				children: [chat.map((turn) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "border-s-2 border-line ps-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold text-copper",
						children: turn.role === "user" ? "شما" : "همدم"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 whitespace-pre-wrap leading-8",
						children: turn.text
					})]
				}, turn.id)), pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-sm text-muted",
					children: "در حال نوشتن پاسخ…"
				}) : null]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl bg-copper-soft px-4 py-3 text-sm leading-7 text-copper",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-3",
				onSubmit: (event) => {
					event.preventDefault();
					send(message);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
					value: message,
					maxLength: 1200,
					placeholder: "مثلاً: پرتودرمانی با شیمی‌درمانی چه فرقی دارد؟",
					onChange: (event) => setMessage(event.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: pending || !message.trim(),
						children: "پرسیدن"
					}), chat.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						tone: "quiet",
						onClick: clearChat,
						children: "پاک کردن گفتگو"
					}) : null]
				})]
			})
		]
	});
}
//#endregion
export { CompanionPage as component };
