import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as PageIntro } from "./router-CElB2d5Z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scope-BAUT0yXR.js
var import_jsx_runtime = require_jsx_runtime();
var rows = [
	[
		"اطلاع‌رسانی درمان",
		"هست",
		"آموزش عمومی و محافظه‌کار. بازنشر NCCN یا پروتکل بیمارستانی نیست."
	],
	[
		"دفتر حال و پیگیری نوبت",
		"هست",
		"درد، خستگی، تب و تقویم ویزیت، آزمایش، تصویر و جلسهٔ درمان."
	],
	[
		"فرم پیش از ویزیت",
		"هست",
		"برای خواندن سر ویزیت. به پروندهٔ بیمارستان وصل نیست."
	],
	[
		"سابقهٔ خانوادگی",
		"هست، محلی",
		"یادآوری برای پزشک، نه محاسبهٔ خطر ژنتیکی."
	],
	[
		"حمایت روانی و اجتماعی",
		"هست",
		"مسیر مددکاری، بدون تلفن ساختگی."
	],
	[
		"همراه هوشمند",
		"هست، آموزشی",
		"پرسش کاربر. تشخیص، دوز دارو و آمار ساختگی ممنوع شده است."
	],
	[
		"قاعدهٔ هشدار",
		"هست و شفاف",
		"فقط بر اساس علامت‌هایی که خود بیمار زده. جعبهٔ سیاه نیست."
	],
	[
		"شبکهٔ عصبی تشخیص سرطان",
		"نیست",
		"بدون دادهٔ دارای رضایت، آزمون خارجی و مجوز، خروجی‌اش تصمیم پزشکی خطرناک است."
	],
	[
		"پیش‌بینی متاستاز",
		"نیست",
		"این کار تصویر و قضاوت بالینی است، نه متن یک فرم."
	],
	[
		"هولتر و پالس‌اکسی‌متر",
		"نیست",
		"اتصال دستگاه، نرم‌افزار دستگاه پزشکی است و ایمنی سیگنال می‌خواهد."
	],
	[
		"خواندن خودکار EMR کلینیک",
		"نیست",
		"نیاز به رابط بیمارستان، رضایت و کنترل دسترسی دارد."
	],
	[
		"حساب ابری و ورود",
		"نیست",
		"دادهٔ سلامت تا آماده شدن امنیت و رضایت، روی دستگاه خود کاربر می‌ماند."
	]
];
function ScopePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
				kicker: "نظر تخصصی روی نسخهٔ اول",
				title: "اول ابزار پیگیری امن، بعد ادعای هوش تشخیصی.",
				lede: "طرح، وب‌اپلیکیشنی برای اطلاع‌رسانی درمان سرطان، پشتیبانی بیمار و پیگیری وضعیت در بیمارستان آیت‌الله رئیسی است. این نسخه همان مرحلهٔ اول قابل‌دفاع است: چیزی که بیمار امروز بتواند استفاده کند، بدون اینکه نرم‌افزار جای پزشک را بگیرد."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-card border border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[40rem] text-right text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-foam text-cypress-deep",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-semibold",
								children: "قابلیت طرح"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-semibold",
								children: "نسخهٔ اول"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-semibold",
								children: "دلیل"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map(([feature, status, why]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line align-top",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: feature
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 whitespace-nowrap",
								children: status
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 leading-6 text-muted",
								children: why
							})
						]
					}, feature)) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "max-w-2xl leading-8 text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-bold text-ink",
						children: "چرا مدل تشخیصی را به نسخهٔ اول نیاوردیم"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3",
						children: "تشخیص زودهنگام و هشدار متاستاز در طرح آمده‌اند، اما یک شبکهٔ عصبی که روی دادهٔ واقعیِ دارای رضایت آموزش ندیده و با مجموعهٔ آزمون مستقل سنجیده نشده، دقت بالینی ندارد. اگر خروجی‌اش را «تشخیص» بنامیم، بیمار ممکن است یا آسوده شود و مراجعه را عقب بیندازد، یا بی‌جهت بترسد. تا پیش از مسیر کیفیت نرم‌افزار پزشکی، این کار محصول آزمایشگاهی قابل‌عرضه به بیمار نیست."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3",
						children: "استانداردهایی که در طرح نام برده شده — از جمله مدیریت امنیت اطلاعات، کیفیت وسیلهٔ پزشکی، و حریم داده — پروژهٔ انطباق‌اند، نه یک برچسب در پاصفحه. در این نسخه داده از دستگاه خارج نمی‌شود و شمارهٔ تماس افراد حقیقی طرح هم منتشر نشده است."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3",
						children: "ناظر علمی طرح دکتر مهرداد پاینده است. نقش سخت‌افزار وقتی معنی پیدا می‌کند که اتصال دستگاه، با مجوز، واقعاً وارد محدوده شود. تا آن روز کار نسخهٔ اول نرم‌افزار است: آموزش، دفتر پیگیری، فرم ویزیت و حمایت."
					})
				]
			})
		]
	});
}
//#endregion
export { ScopePage as component };
