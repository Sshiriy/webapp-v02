import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react, _ as lazyRouteComponent, b as Link, f as Scripts, g as Outlet, h as createRouter, p as HeadContent, v as createFileRoute, x as useRouter, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { a as object, i as number, o as string, r as literal, s as union } from "../_libs/zod.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { a as House, c as BookOpen, i as MessagesSquare, n as TriangleAlert, o as HeartHandshake, s as ClipboardList, t as UserRound, u as Activity } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-CQFk7eZh.js
var import_jsx_runtime = require_jsx_runtime();
function cx(...parts) {
	return parts.filter(Boolean).join(" ");
}
function Card({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cx("rounded-card border border-line bg-surface px-5 py-5 shadow-[0_1px_0_rgba(28,42,39,0.04),0_16px_40px_rgba(28,42,39,0.04)]", className),
		children
	});
}
function Button({ tone = "primary", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cx("inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold transition-colors duration-200 disabled:cursor-not-allowed disabled:opacity-50", tone === "primary" && "bg-cypress text-paper hover:bg-cypress-deep", tone === "quiet" && "border border-line bg-surface text-ink hover:bg-foam", tone === "copper" && "bg-copper text-paper hover:bg-cypress-deep", className),
		...props
	});
}
function Field({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium text-ink",
				children: label
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-sm text-muted",
				children: hint
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2",
				children
			})
		]
	});
}
var control = "w-full rounded-xl border border-line bg-paper px-3 py-2.5 text-base text-ink outline-none ring-cypress placeholder:text-muted/70 focus:ring-2";
function TextInput(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...props,
		className: cx(control, props.className)
	});
}
function TextArea(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		...props,
		className: cx(control, "min-h-28 resize-y leading-7", props.className)
	});
}
function Select({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		...props,
		className: cx(control, "min-h-11", className),
		children
	});
}
function PageIntro({ kicker, title, lede }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-copper",
				children: kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-3xl font-extrabold tracking-tight text-ink sm:text-4xl",
				children: title
			}),
			lede ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-lg leading-8 text-muted",
				children: lede
			}) : null
		]
	});
}
function Disclaimer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-xl border border-line bg-foam px-4 py-3 text-sm leading-6 text-cypress-deep",
		children: "همدم ابزار اطلاع‌رسانی و پیگیری است، نه تشخیص، نه نسخه‌نویسی، و نه جایگزین ویزیت پزشک یا اورژانس."
	});
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/store-CFfN1nO-.js
var longDate = new Intl.DateTimeFormat("fa-IR-u-ca-persian", {
	year: "numeric",
	month: "long",
	day: "numeric"
});
var shortDate = new Intl.DateTimeFormat("fa-IR-u-ca-persian", {
	month: "short",
	day: "numeric"
});
function todayISO() {
	const d = /* @__PURE__ */ new Date();
	const m = String(d.getMonth() + 1).padStart(2, "0");
	const day = String(d.getDate()).padStart(2, "0");
	return `${d.getFullYear()}-${m}-${day}`;
}
function asDate(iso) {
	const value = iso.length === 10 ? `${iso}T12:00:00` : iso;
	const date = new Date(value);
	return Number.isNaN(date.getTime()) ? null : date;
}
function formatFa(iso) {
	const date = asDate(iso);
	return date ? longDate.format(date) : iso;
}
function formatFaShort(iso) {
	const date = asDate(iso);
	return date ? shortDate.format(date) : iso;
}
function daysUntil(iso) {
	const date = asDate(iso);
	if (!date) return null;
	const now = /* @__PURE__ */ new Date();
	now.setHours(12, 0, 0, 0);
	return Math.round((date.getTime() - now.getTime()) / 864e5);
}
function relativeDay(iso) {
	const days = daysUntil(iso);
	if (days === null) return "";
	if (days === 0) return "امروز";
	if (days === 1) return "فردا";
	if (days === -1) return "دیروز";
	if (days > 1) return `${new Intl.NumberFormat("fa-IR").format(days)} روز دیگر`;
	return `${new Intl.NumberFormat("fa-IR").format(Math.abs(days))} روز پیش`;
}
function faNum(value) {
	return new Intl.NumberFormat("fa-IR").format(value);
}
function safeTel(phone) {
	const trimmed = phone.trim();
	if (!/^[0-9+][0-9+\-\s]{6,}$/.test(trimmed)) return null;
	return `tel:${trimmed.replace(/[\s-]/g, "")}`;
}
var cancerOptions = [
	{
		id: "unknown",
		label: "هنوز مشخص نیست"
	},
	{
		id: "breast",
		label: "پستان"
	},
	{
		id: "colorectal",
		label: "روده بزرگ"
	},
	{
		id: "lung",
		label: "ریه"
	},
	{
		id: "prostate",
		label: "پروستات"
	},
	{
		id: "liver",
		label: "کبد"
	},
	{
		id: "skin",
		label: "پوست"
	},
	{
		id: "other",
		label: "نوع دیگر"
	}
];
var checkupKinds = [
	{
		id: "visit",
		label: "ویزیت پزشک"
	},
	{
		id: "lab",
		label: "آزمایش"
	},
	{
		id: "imaging",
		label: "تصویربرداری"
	},
	{
		id: "infusion",
		label: "جلسهٔ درمان"
	},
	{
		id: "other",
		label: "سایر"
	}
];
var emptyProfile = {
	name: "",
	age: "",
	sex: "unspecified",
	cancerId: "unknown",
	cancerNote: "",
	diagnosisYear: "",
	doctor: "",
	city: "کرمانشاه",
	clinicPhone: "",
	demo: false,
	onboarded: false
};
var emptyVisit = {
	sinceLast: "",
	meds: "",
	newSymptoms: "",
	questions: "",
	mood: 5,
	painNow: 0
};
function uid() {
	return crypto.randomUUID();
}
function shiftISO(days) {
	const date = /* @__PURE__ */ new Date();
	date.setDate(date.getDate() + days);
	const m = String(date.getMonth() + 1).padStart(2, "0");
	const day = String(date.getDate()).padStart(2, "0");
	return `${date.getFullYear()}-${m}-${day}`;
}
var initial = {
	profile: emptyProfile,
	family: [],
	symptoms: [],
	checkups: [],
	visit: emptyVisit,
	chat: []
};
var useCare = create()(persist((set) => ({
	...initial,
	saveProfile: (profile) => set({ profile }),
	addFamily: (member) => set((state) => ({ family: [{
		...member,
		id: uid()
	}, ...state.family] })),
	removeFamily: (id) => set((state) => ({ family: state.family.filter((item) => item.id !== id) })),
	addSymptom: (symptom) => set((state) => ({ symptoms: [{
		...symptom,
		id: uid()
	}, ...state.symptoms] })),
	removeSymptom: (id) => set((state) => ({ symptoms: state.symptoms.filter((item) => item.id !== id) })),
	addCheckup: (checkup) => set((state) => ({ checkups: [{
		...checkup,
		id: uid()
	}, ...state.checkups] })),
	updateCheckup: (id, patch) => set((state) => ({ checkups: state.checkups.map((item) => item.id === id ? {
		...item,
		...patch
	} : item) })),
	removeCheckup: (id) => set((state) => ({ checkups: state.checkups.filter((item) => item.id !== id) })),
	setVisit: (visit) => set({ visit }),
	addChat: (turn) => set((state) => ({ chat: [...state.chat, {
		...turn,
		id: uid()
	}] })),
	clearChat: () => set({ chat: [] }),
	loadDemo: () => set({
		profile: {
			name: "سارا مرادی",
			age: "۴۶",
			sex: "female",
			cancerId: "breast",
			cancerNote: "",
			diagnosisYear: "۱۴۰۳",
			doctor: "تیم درمان بیمارستان آیت‌الله رئیسی",
			city: "کرمانشاه",
			clinicPhone: "",
			demo: true,
			onboarded: true
		},
		family: [{
			id: uid(),
			relation: "مادر",
			condition: "سرطان پستان",
			ageAt: "۵۸",
			note: "نمونهٔ نمایشی؛ سابقهٔ واقعی نیست."
		}],
		symptoms: [
			{
				id: uid(),
				date: shiftISO(-10),
				pain: 3,
				fatigue: 4,
				nausea: 2,
				appetite: 7,
				mood: 6,
				fever: false,
				breath: false,
				bleeding: false,
				vomiting: false,
				confusion: false,
				weight: "stable",
				note: "روز آرام پس از جلسهٔ درمان. نمونهٔ نمایشی."
			},
			{
				id: uid(),
				date: shiftISO(-6),
				pain: 4,
				fatigue: 6,
				nausea: 5,
				appetite: 5,
				mood: 5,
				fever: false,
				breath: false,
				bleeding: false,
				vomiting: false,
				confusion: false,
				weight: "stable",
				note: "تهوع عصرها بیشتر بود."
			},
			{
				id: uid(),
				date: shiftISO(-1),
				pain: 6,
				fatigue: 7,
				nausea: 4,
				appetite: 4,
				mood: 4,
				fever: false,
				breath: false,
				bleeding: false,
				vomiting: false,
				confusion: false,
				weight: "down",
				note: "درد بازو کمی بیشتر شده. وزن را دقیق نسنجیده‌ام."
			}
		],
		checkups: [
			{
				id: uid(),
				title: "آزمایش خون پیش از جلسه",
				date: shiftISO(-4),
				kind: "lab",
				place: "آزمایشگاه بیمارستان",
				done: true,
				note: "نتیجه نزد پزشک است. این یادداشت ساختگی است."
			},
			{
				id: uid(),
				title: "ویزیت انکولوژی",
				date: shiftISO(5),
				kind: "visit",
				place: "بیمارستان آیت‌الله رئیسی",
				done: false,
				note: ""
			},
			{
				id: uid(),
				title: "جلسهٔ درمان",
				date: shiftISO(6),
				kind: "infusion",
				place: "بخش درمان",
				done: false,
				note: ""
			}
		],
		visit: {
			sinceLast: "خستگی عصرها بیشتر شده و آستین سمت جراحی کمی سفت است.",
			meds: "داروهای ضدتهوع را دو شب جا انداخته‌ام.",
			newSymptoms: "کاهش اشتها. تب نداشته‌ام.",
			questions: "آیا تورم بازو نیاز به مراجعهٔ جدا دارد؟ آزمایش بعدی کی است؟",
			mood: 4,
			painNow: 6
		},
		chat: []
	}),
	clearAll: () => set({
		...initial,
		visit: { ...emptyVisit },
		profile: { ...emptyProfile }
	})
}), {
	name: "hamdam-v1",
	skipHydration: true,
	partialize: (state) => ({
		profile: state.profile,
		family: state.family,
		symptoms: state.symptoms,
		checkups: state.checkups,
		visit: state.visit,
		chat: state.chat
	})
}));
function cancerLabel(profile) {
	const known = cancerOptions.find((item) => item.id === profile.cancerId)?.label;
	if (profile.cancerId === "other" && profile.cancerNote.trim()) return profile.cancerNote.trim();
	return known ?? "نامشخص";
}
function upcomingCheckups(checkups) {
	const today = todayISO();
	return [...checkups].filter((item) => !item.done && item.date >= today).sort((a, b) => a.date.localeCompare(b.date));
}
function orderedSymptoms(symptoms) {
	return [...symptoms].sort((a, b) => a.date.localeCompare(b.date));
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/articles-aWE-m8ku.js
var articles = [
	{
		slug: "breast",
		kind: "cancer",
		title: "سرطان پستان",
		kicker: "آموزش بیمار",
		summary: "شایع‌ترین سرطان در زنان است و در مردان هم، هرچند نادر، دیده می‌شود. قطعیت تشخیص با معاینهٔ تنها به دست نمی‌آید؛ نمونه‌برداری و گزارش پاتولوژی محور تصمیم‌اند.",
		sections: [
			{
				heading: "مسیر معمول تا تشخیص",
				paragraphs: ["توده، ترشح نوک پستان، فرورفتگی پوست یا تغییر تازه‌ای که خودتان متوجه شده‌اید دلیل مراجعه است، نه برچسب بیماری. پزشک ممکن است معاینه، ماموگرافی، سونوگرافی و در صورت نیاز نمونه‌برداری بخواهد.", "تا جواب بافت‌شناسی نرسد، هیچ نرم‌افزاری — از جمله همدم — نباید بگوید این ضایعه سرطان هست یا نیست."]
			},
			{
				heading: "چیزی که برنامهٔ درمان را عوض می‌کند",
				paragraphs: ["در گزارش پاتولوژی معمولاً از گیرنده‌های هورمونی (ER و PR) و وضعیت HER2 حرف زده می‌شود. این‌ها نام دارو نیستند؛ ویژگی‌های تومورند که مشخص می‌کنند هورمون‌درمانی، درمان هدفمند، شیمی‌درمانی، جراحی یا پرتودرمانی هر کدام چه جایی دارند.", "ترکیب درمان را تیم شما می‌چیند. دو بیمار با «سرطان پستان» ممکن است مسیر کاملاً متفاوتی داشته باشند."]
			},
			{
				heading: "بین ویزیت‌ها به چه چیز توجه شود",
				paragraphs: ["تب در دورهٔ شیمی‌درمانی، تورم تازه و پیشروندهٔ بازو، تنگی نفس، خونریزی غیرمعمول و دردی که با مسکن تجویزشده آرام نمی‌شود را همان روز خبر دهید. آستانهٔ تب را روی کارت درمان از پرستاران بپرسید و در پروندهٔ همدم یادداشت کنید."]
			}
		],
		askDoctor: [
			"گیرنده‌های هورمونی و HER2 در گزارش من چه وضعی دارند؟",
			"جراحی، پرتو و دارو هر کدام برای من چه نقشی دارند؟",
			"علائم لنف‌ادم را کی باید جدی بگیرم؟",
			"ویزیت و تصویربرداری بعدی دقیقاً چه تاریخی است؟"
		]
	},
	{
		slug: "colorectal",
		kind: "cancer",
		title: "سرطان روده بزرگ",
		kicker: "آموزش بیمار",
		summary: "کولون و رکتوم را در بر می‌گیرد. تشخیص با کولونوسکوپی و نمونه‌برداری مسجل می‌شود، نه با یک آزمایش خون به‌تنهایی.",
		sections: [
			{
				heading: "آنچه بیمار باید از مسیر بداند",
				paragraphs: ["خون در مدفوع، تغییر تازه‌ماندهٔ اجابت مزاج، کم‌خونی یا درد شکم دلیل بررسی‌اند. وجود این‌ها به معنی سرطان نیست و نبودشان هم سرطان را رد نمی‌کند.", "پس از تشخیص، عمق درگیری دیواره، غدد لنفاوی و وجود گسترش دوردست را پزشک با پاتولوژی و تصویربرداری جمع می‌کند. مرحله را از روی احساس یا یک پرسشنامه اعلام نمی‌کنند."]
			},
			{
				heading: "درمان، به زبان ساده",
				paragraphs: ["برای بسیاری از بیماران جراحی بخش اصلی درمان است. شیمی‌درمانی بسته به یافته‌های پاتولوژی ممکن است قبل یا بعد از جراحی مطرح شود. پرتودرمانی بیشتر در تومورهای رکتوم به بحث گذاشته می‌شود.", "اگر استومی (کیسهٔ روده‌ای) مطرح است، آموزش پرستاری و زمان برگشت احتمالی را قبل از عمل بپرسید، نه شب عمل."]
			},
			{
				heading: "هشدارهایی که نباید تا نوبت بعدی بمانند",
				paragraphs: ["درد شدید و فزایندهٔ شکم، استفراغ مکرر، نفخ شدید با قطع دفع گاز، تب، و خونریزی تازه و زیاد می‌توانند نشانهٔ انسداد یا عارضه باشند و تماس همان روز می‌خواهند."]
			}
		],
		askDoctor: [
			"تومور در کولون است یا رکتوم، و این فرق برای درمان من چیست؟",
			"آیا قبل از جراحی درمان دارویی لازم است؟",
			"کدام علائم را باید همان روز خبر دهم؟",
			"برنامهٔ کولونوسکوپی بعد از درمان چیست؟"
		]
	},
	{
		slug: "lung",
		kind: "cancer",
		title: "سرطان ریه",
		kicker: "آموزش بیمار",
		summary: "انواع اصلی‌اش از نظر سلول و نشانگرها با هم فرق دارند و همین فرق، دارو را عوض می‌کند. تصویر غیرطبیعی ریه به‌خودی‌خود تشخیص نهایی نیست.",
		sections: [{
			heading: "تشخیص چطور مسجل می‌شود",
			paragraphs: ["سی‌تی‌اسکن نقطهٔ شروع رایجی است. برای نام‌گذاری بیماری معمولاً نمونه‌برداری لازم است. آزمایش‌های تکمیلی ممکن است نشانگرهایی را بررسی کنند که درمان هدفمند یا ایمنی‌درمانی را ممکن می‌کنند.", "این آزمایش‌ها را باید تیم درمان درخواست و تفسیر کند. همدم نتیجه‌شان را «مثبت یا منفیِ سرطان» اعلام نمی‌کند."]
		}, {
			heading: "زندگی روزمره",
			paragraphs: ["ترک دخانیات، حتی بعد از تشخیص، اغلب هنوز فایده دارد؛ قضاوت اخلاقی نیست، یک بحث درمانی است و کمک تخصصی می‌خواهد.", "تنگی نفس ناگهانی، درد قفسهٔ سینه، خلط خونی، گیجی یا سردرد شدید و یک‌طرفه، و تب را همان روز اطلاع دهید."]
		}],
		askDoctor: [
			"نوع سلولی بیماری من چیست و چه آزمایش نشانگری انجام شده است؟",
			"هدف این مرحله از درمان کنترل موضعی است یا درمان دارویی سراسری؟",
			"اگر نفس‌تنگی شب‌هنگام بدتر شد به کجا زنگ بزنم؟"
		]
	},
	{
		slug: "prostate",
		kind: "cancer",
		title: "سرطان پروستات",
		kicker: "آموزش بیمار",
		summary: "بسیار شایع است و رفتارش از بیماری بسیار کند تا بیماری جدی متفاوت است. آزمایش PSA به‌تنهایی تشخیص سرطان نیست.",
		sections: [{
			heading: "PSA و معاینه",
			paragraphs: ["PSA می‌تواند در بزرگی خوش‌خیم پروستات، التهاب و بعد از بعضی معاینه‌ها هم بالا برود. تصمیم نمونه‌برداری با اورولوژیست است، نه با یک عدد تنها.", "پس از تشخیص، گروه خطر را پزشک با معاینه، PSA و درجهٔ پاتولوژی (نمرهٔ گلیسون) توضیح می‌دهد. این گروه خطر را در خانه محاسبه نکنید."]
		}, {
			heading: "گزینه‌هایی که ممکن است بشنوید",
			paragraphs: ["برای برخی بیماران پایش فعال یک درمان واقعی است، نه بی‌عملی. برای دیگران جراحی، پرتودرمانی یا هورمون‌درمانی مطرح می‌شود. عارضه‌های احتمالی بر ادرار، روده و عملکرد جنسی باید قبل از انتخاب، با عدد و زبان روشن گفته شود."]
		}],
		askDoctor: [
			"بیماری من در کدام گروه خطر است و پایش فعال برایم معنی دارد یا نه؟",
			"عارضه‌های گزینه‌های پیش رو را برای سن و بقیهٔ بیماری‌های من چطور می‌سنجید؟",
			"PSA را با چه فاصله‌ای تکرار کنیم و چه تغییری مهم است؟"
		]
	},
	{
		slug: "liver",
		kind: "cancer",
		title: "کبد؛ تومور اولیه یا گسترش از جای دیگر",
		kicker: "آموزش بیمار",
		summary: "ضایعهٔ کبد همیشه یک بیماری واحد نیست. سرطان اولیهٔ کبد با متاستاز سرطان‌های دیگر به کبد مسیر درمانی متفاوتی دارد. این تفاوت را تصویر و نمونه‌برداری مشخص می‌کند، نه نرم‌افزار.",
		sections: [{
			heading: "چرا این تفکیک مهم است",
			paragraphs: ["سرطان اولیه اغلب روی زمینهٔ بیماری مزمن کبد، مانند هپاتیت یا سیروز، دیده می‌شود. متاستاز یعنی سرطان از عضو دیگری به کبد رسیده و درمانش تابع سرطان مبدأ است.", "همدم هیچ‌کدام را از روی علامت حدس نمی‌زند. اگر در نامهٔ تصویربرداری هر دو احتمال آمده، سؤال اول ویزیت همین تفکیک است."]
		}, {
			heading: "علائمی که باید زودتر گفته شوند",
			paragraphs: ["زردی پیشروندهٔ چشم و پوست، تورم سریع شکم، خواب‌آلودگی غیرعادی، استفراغ خونی یا مدفوع سیاه، و تب را به نوبت بعدی موکول نکنید."]
		}],
		askDoctor: [
			"این ضایعه اولیه است یا گسترش از عضو دیگر؟",
			"آیا نمونه‌برداری لازم است یا تشخیص با تصویر و آزمایش خون کافی دانسته شده و چرا؟",
			"علائمی که مربوط به نارسایی کبد باشد را برای من فهرست کنید."
		]
	},
	{
		slug: "skin",
		kind: "cancer",
		title: "سرطان پوست",
		kicker: "آموزش بیمار",
		summary: "تغییر خال دلیل مراجعه به پزشک است، نه دلیل اینکه خودتان یا یک برنامه آن را ملانوم بنامید. تشخیص با برداشتن ضایعه و پاتولوژی است.",
		sections: [{
			heading: "چه تغییری ارزش ویزیت دارد",
			paragraphs: ["عدم تقارن، مرز نامنظم، چندرنگی، قطر در حال رشد، و هر تغییری که نسبت به عکس چند ماه قبل تازه باشد. خارش یا خونریزی خال هم دلیل بررسی است.", "این نشانه‌ها حساس‌اند نه اختصاصی؛ بسیاری از خال‌های تغییرکرده خوش‌خیم‌اند و بعضی سرطان‌های پوست این فهرست را کامل پر نمی‌کنند."]
		}, {
			heading: "بعد از برداشتن",
			paragraphs: ["اگر گزارش ملانوم یا سرطان دیگر باشد، حاشیهٔ جراحی و نیاز به نمونه‌برداری غده یا درمان تکمیلی را جراح و انکولوژیست می‌گویند. مراقبت از زخم، آفتاب و ویزیت‌های پوست را مکتوب تحویل بگیرید."]
		}],
		askDoctor: [
			"نوع دقیق پاتولوژی و عمق یا حاشیه چه بوده است؟",
			"آیا بررسی غدد لنفاوی برای من مطرح است؟",
			"پوست را خودم با چه فاصله‌ای نگاه کنم و چه چیزی را زود خبر دهم؟"
		]
	},
	{
		slug: "treatment-paths",
		kind: "guide",
		title: "خانواده‌های درمان، بدون وعده",
		kicker: "راهنما",
		summary: "نام درمان‌ها در گفتگوهای بیمارستان زیاد تکرار می‌شود. این صفحه فقط واژه‌نامه است تا سر ویزیت بفهمید چه می‌شنوید. انتخاب درمان با تیم شماست.",
		sections: [
			{
				heading: "جراحی",
				paragraphs: ["برداشتن تومور یا عضو درگیر. سؤال‌های مفید: هدف عمل درمان قطعی است یا کم کردن حجم، دوران بستری، و چه عارضه‌ای را باید شب اول جدی بگیرید."]
			},
			{
				heading: "شیمی‌درمانی",
				paragraphs: ["داروهایی که سلول‌های در حال تقسیم را هدف می‌گیرند و به سلول سالم هم اثر می‌گذارند. تهوع، افت خون، ریزش مو و خستگی شایع‌اند اما برای همه یکسان نیستند. تب هنگام افت گلبول سفید اورژانس درمانی است."]
			},
			{
				heading: "پرتودرمانی",
				paragraphs: ["تابش متمرکز به یک ناحیه. پوست ناحیه، خستگی و علائم موضعی (بسته به محل تابش) موضوع آموزش پرستاری پرتودرمانی است. کرم و شست‌وشو را از همان واحد بپرسید، نه از منابع پراکنده."]
			},
			{
				heading: "درمان هدفمند، ایمنی‌درمانی، هورمون‌درمانی",
				paragraphs: ["این‌ها سه خانوادهٔ متفاوت‌اند. هدفمند به یک ویژگی مشخص تومور وابسته است. ایمنی‌درمانی سیستم ایمنی را درگیر می‌کند و عوارضش می‌تواند دیررس و شبیه بیماری خودایمن باشد. هورمون‌درمانی مسیر هورمونی تغذیهٔ بعضی تومورها را کم می‌کند.", "هیچ‌کدام «قوی‌تر بودن مطلق» نیست. بودن یا نبودنشان را گزارش پاتولوژی و مرحله تعیین می‌کند."]
			}
		],
		askDoctor: [
			"هدف درمان من در این مرحله چیست: حذف بیماری، کنترل، یا کاهش علامت؟",
			"کدام عارضه را باید همان روز خبر دهم و شمارهٔ تماس کیست؟",
			"اگر یک دوز را به‌خاطر آزمایش عقب بیندازیم، معنی‌اش چیست؟"
		]
	},
	{
		slug: "between-visits",
		kind: "guide",
		title: "روزهای بین دو ویزیت",
		kicker: "راهنما",
		summary: "بیشتر مراقبت بیرون از مطب اتفاق می‌افتد. همدم برای همین فاصله ساخته شده: ثبت حال، نه تفسیر آزمایش به‌جای پزشک.",
		sections: [{
			heading: "چه چیزی ارزش نوشتن دارد",
			paragraphs: ["درد را با عدد ۰ تا ۱۰ و با محل بنویسید. تب را با عدد دما، نه فقط «حالم گرم بود». وزن را با همان ترازو و همان ساعت. دارویی را که جا انداخته‌اید پنهان نکنید؛ پزشک به آن برای تنظیم برنامه نیاز دارد."],
			bullets: [
				"ساعت و عدد تب",
				"دفعاتی که استفراغ یا اسهال داشته‌اید",
				"دردی که الگوی تازه‌ای پیدا کرده",
				"سؤالی که وسط شب به ذهن‌تان رسیده"
			]
		}, {
			heading: "چه چیزی را به نوبت بعدی نسپارید",
			paragraphs: ["تب در دورهٔ درمان دارویی، تنگی نفس، خونریزی، درد قفسهٔ سینه، گیجی، استفراغ مهارنشده، و هر علامتی که تیم‌تان روی برگهٔ ترخیص «زنگ بزنید» نوشته است."]
		}],
		askDoctor: [
			"شمارهٔ تماس روز و شب بخش چیست؟",
			"کدام مسکن را مجازم و کدام را نباید با درمان فعلی‌ام بخورم؟",
			"آزمایش را چند روز قبل از ویزیت بدهم که جواب به جلسه برسد؟"
		]
	},
	{
		slug: "visit-questions",
		kind: "guide",
		title: "سر ویزیت چه بپرسید",
		kicker: "راهنما",
		summary: "ویزیت کوتاه است. اگر سؤال را از خانه نوشته باشید، وقت صرف یادآوری حال‌تان نمی‌شود. فرم پیش از ویزیت همدم همین کار را می‌کند.",
		sections: [{
			heading: "پنج سؤال که تقریباً همیشه به‌کار می‌آیند",
			paragraphs: ["این‌ها جایگزین شرح‌حال پزشک نیستند؛ کمک می‌کنند چیزی ناگفته نماند."],
			bullets: [
				"امروز چه تصمیمی گرفته می‌شود و چه تصمیمی عمداً به بعد موکول است؟",
				"نتیجهٔ آزمایش یا تصویر قبلی را خودتان دیده‌اید؟",
				"عارضهٔ محتمل این گام بعدی چیست و نشانهٔ خطرش کدام است؟",
				"داروی جدید را با غذا، با چه فاصله از داروهای قبلی، و تا کی بخورم؟",
				"ویزیت بعدی کی است و اگر آن تاریخ پر شد به کجا مراجعه کنم؟"
			]
		}, {
			heading: "همراه را با خود ببرید",
			paragraphs: ["اضطراب، حافظه را کم می‌کند. یک نفر که یادداشت بردارد بهتر از ضبط پنهانی است. اگر تنها می‌روید، فرم پیش از ویزیت را پرینت کنید یا از روی صفحه برای پزشک بخوانید."]
		}],
		askDoctor: ["جمع‌بندی امروز را در یک جمله بگویید تا در پرونده‌ام بنویسم.", "کدام بخش حرف امروزتان را باید خانواده هم بداند؟"]
	},
	{
		slug: "fever",
		kind: "guide",
		title: "تب و نشانه‌های فوری",
		kicker: "راهنما",
		summary: "این صفحه تشخیص عفونت نمی‌دهد. فقط می‌گوید کدام علامت‌ها در عرف مراقبت سرطان به تماس همان روز معروف‌اند.",
		sections: [{
			heading: "تب در طول درمان دارویی",
			paragraphs: ["بعضی داروهای شیمی‌درمانی گلبول سفید را پایین می‌آورند. در آن پنجره، تب می‌تواند تنها علامت عفونت جدی باشد. بسیاری از واحدهای شیمی‌درمانی به بیماران می‌گویند از ۳۸ درجه بالاتر — یا آستانه‌ای که خودشان تعیین کرده‌اند — حتی نیمه‌شب تماس بگیرند و منتظر صبح نمانند.", "آستانه را از برگهٔ آموزش همان بخش بردارید و در شمارهٔ درمانگاه داخل پرونده ذخیره کنید. عدد اینترنت را جایگزین دستور بخش نکنید."]
		}, {
			heading: "فهرست تماس همان روز",
			paragraphs: ["اگر هر کدام را دارید، دفترچه را پر کنید و تماس بگیرید. همدم به‌جای اورژانس تصمیم نمی‌گیرد."],
			bullets: [
				"تب، لرز",
				"تنگی نفس تازه یا درد قفسهٔ سینه",
				"خونریزی که بند نمی‌آید، استفراغ خونی، مدفوع سیاه",
				"استفراغ یا اسهالی که مایع نمی‌ماند",
				"گیجی، غش، ضعف یک‌طرفهٔ بدن، سردرد ناگهانی شدید",
				"درد ناگهانی و شدید شکم"
			]
		}],
		askDoctor: [
			"عدد تب مهم برای پروتکل من چند است؟",
			"شب و روز تعطیل به کدام شماره زنگ بزنم؟",
			"آیا باید قبل از تماس خودسرانه آنتی‌بیوتیک یا تب‌بر بخورم؟"
		]
	}
];
function getArticle(slug) {
	return articles.find((article) => article.slug === slug);
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-CElB2d5Z.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var nav = [
	{
		to: "/",
		label: "خانه",
		icon: House,
		exact: true
	},
	{
		to: "/learn",
		label: "آموزش",
		icon: BookOpen,
		exact: false
	},
	{
		to: "/track",
		label: "پیگیری",
		icon: Activity,
		exact: false
	},
	{
		to: "/visit",
		label: "پیش‌ویزیت",
		icon: ClipboardList,
		exact: false
	},
	{
		to: "/support",
		label: "حمایت",
		icon: HeartHandshake,
		exact: false
	}
];
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "16",
			cy: "16",
			r: "13.25",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.5"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 7.2c.2 2.4-.2 4.2-1.4 6.1-1.1 1.7-1.8 3-1.8 4.6a3.2 3.2 0 0 0 6.4 0c0-1.6-.7-2.9-1.8-4.6-1.2-1.9-1.6-3.7-1.4-6.1Z",
			fill: "currentColor"
		})]
	});
}
function Shell({ children }) {
	(0, import_react.useEffect)(() => {
		const current = useCare.getState();
		if (current.profile.onboarded || current.profile.name.length > 0 || current.symptoms.length > 0 || current.checkups.length > 0 || current.family.length > 0 || current.chat.length > 0 || current.visit.sinceLast.length > 0 || current.visit.questions.length > 0) return;
		try {
			const raw = localStorage.getItem("hamdam-v1");
			if (!raw) return;
			const saved = JSON.parse(raw).state;
			if (!saved) return;
			useCare.setState({
				profile: saved.profile ?? current.profile,
				family: saved.family ?? [],
				symptoms: saved.symptoms ?? [],
				checkups: saved.checkups ?? [],
				visit: saved.visit ?? current.visit,
				chat: saved.chat ?? []
			});
		} catch {}
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "no-print border-b border-line bg-paper/95 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-5xl items-center gap-4 px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							className: "flex min-w-0 items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-10 shrink-0 place-items-center rounded-full bg-cypress text-paper",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-7" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-lg font-extrabold leading-none tracking-tight",
									children: "همدم"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block truncate text-xs text-muted",
									children: "بیمارستان آیت‌الله رئیسی · کرمانشاه"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "ms-auto hidden items-center gap-1 lg:flex",
							children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: item.to,
								activeOptions: { exact: item.exact },
								className: "rounded-full px-3 py-2 text-sm",
								activeProps: { className: "bg-foam font-semibold text-cypress" },
								inactiveProps: { className: "text-muted" },
								children: item.label
							}, item.to))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "ms-auto flex items-center gap-2 lg:ms-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/companion",
								className: "inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-surface px-3 text-sm font-medium",
								activeProps: { className: "border-cypress bg-foam font-semibold text-cypress" },
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessagesSquare, {
									className: "size-4",
									strokeWidth: 1.75
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: "همراه هوشمند"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/file",
								"aria-label": "پرونده",
								className: "grid size-11 place-items-center rounded-full border border-line bg-surface",
								activeProps: { className: "border-cypress bg-foam text-cypress" },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, {
									className: "size-5",
									strokeWidth: 1.75
								})
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto w-full max-w-5xl flex-1 px-4 py-6 pb-28 lg:pb-10",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "no-print mx-auto hidden w-full max-w-5xl px-4 pb-8 text-sm text-muted lg:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3 border-t border-line pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "نسخهٔ اول آزمایشی · داده فقط روی همین دستگاه می‌ماند." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/scope",
						className: "font-medium text-cypress",
						children: "محدودهٔ بالینی این نسخه"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "no-print fixed inset-x-0 bottom-0 z-20 border-t border-line bg-surface/95 backdrop-blur lg:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mx-auto grid max-w-lg grid-cols-5",
					children: nav.map((item) => {
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							activeOptions: { exact: item.exact },
							className: "flex min-h-16 flex-col items-center justify-center gap-1 text-[11px]",
							activeProps: { className: "font-semibold text-cypress" },
							inactiveProps: { className: "text-muted" },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								strokeWidth: 1.75
							}), item.label]
						}) }, item.to);
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "top-center",
				dir: "rtl",
				toastOptions: { style: {
					fontFamily: "Vazirmatn, sans-serif",
					background: "var(--color-surface)",
					color: "var(--color-ink)",
					border: "1px solid var(--color-line)"
				} }
			})
		]
	});
}
function LevelChip({ level }) {
	const label = {
		urgent: "تماس امروز",
		soon: "مطرح در ویزیت",
		steady: "پیگیری معمول",
		empty: "بدون ثبت"
	}[level];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cx("inline-flex min-h-8 items-center rounded-full px-3 text-xs font-semibold", level === "urgent" && "bg-copper-soft text-copper", level === "soon" && "bg-foam text-cypress", (level === "steady" || level === "empty") && "bg-paper text-muted ring-1 ring-line"),
		children: label
	});
}
var styles_default = "/assets/styles-CeaQbARO.css";
var Route$9 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "همدم | بیمارستان آیت‌الله رئیسی" },
			{
				name: "description",
				content: "همدم؛ اطلاع‌رسانی درمان سرطان، پیگیری حال و پشتیبانی بیماران بیمارستان آیت‌الله رئیسی کرمانشاه. ابزار آموزشی است، نه تشخیص."
			},
			{
				name: "theme-color",
				content: "#1a5c48"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "fa",
		dir: "rtl",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$8 = () => import("./routes-CwcglZkc.mjs");
var Route$8 = createFileRoute("/")({
	head: () => ({ meta: [{ title: "همدم | بیمارستان آیت‌الله رئیسی" }] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./companion-BGd97MIP.mjs");
var Route$7 = createFileRoute("/companion")({
	head: () => ({ meta: [{ title: "همراه هوشمند | همدم" }] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./file-BpM5NtT1.mjs");
var Route$6 = createFileRoute("/file")({
	head: () => ({ meta: [{ title: "پرونده | همدم" }] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./learn-CQQftWoK.mjs");
var Route$5 = createFileRoute("/learn")({
	head: () => ({ meta: [{ title: "آموزش | همدم" }] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./scope-BAUT0yXR.mjs");
var Route$4 = createFileRoute("/scope")({
	head: () => ({ meta: [{ title: "محدودهٔ نسخهٔ اول | همدم" }] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./support-ISv5opUq.mjs");
var Route$3 = createFileRoute("/support")({
	head: () => ({ meta: [{ title: "حمایت | همدم" }] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./track-BM2u4nKJ.mjs");
var Route$2 = createFileRoute("/track")({
	head: () => ({ meta: [{ title: "پیگیری | همدم" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./visit-CNKVkqlU.mjs");
var Route$1 = createFileRoute("/visit")({
	head: () => ({ meta: [{ title: "پیش از ویزیت | همدم" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./learn._slug-D0A__5sK.mjs");
var Route = createFileRoute("/learn/$slug")({
	head: ({ params }) => ({ meta: [{ title: `${getArticle(params.slug)?.title ?? "آموزش"} | همدم` }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$8.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$9
});
var CompanionRoute = Route$7.update({
	id: "/companion",
	path: "/companion",
	getParentRoute: () => Route$9
});
var FileRoute = Route$6.update({
	id: "/file",
	path: "/file",
	getParentRoute: () => Route$9
});
var LearnRoute = Route$5.update({
	id: "/learn",
	path: "/learn",
	getParentRoute: () => Route$9
});
var ScopeRoute = Route$4.update({
	id: "/scope",
	path: "/scope",
	getParentRoute: () => Route$9
});
var SupportRoute = Route$3.update({
	id: "/support",
	path: "/support",
	getParentRoute: () => Route$9
});
var TrackRoute = Route$2.update({
	id: "/track",
	path: "/track",
	getParentRoute: () => Route$9
});
var VisitRoute = Route$1.update({
	id: "/visit",
	path: "/visit",
	getParentRoute: () => Route$9
});
var LearnRouteChildren = { LearnSlugRoute: Route.update({
	id: "/$slug",
	path: "/$slug",
	getParentRoute: () => LearnRoute
}) };
var rootRouteChildren = {
	IndexRoute,
	CompanionRoute,
	FileRoute,
	LearnRoute: LearnRoute._addFileChildren(LearnRouteChildren),
	ScopeRoute,
	SupportRoute,
	TrackRoute,
	VisitRoute
};
var routeTree = Route$9._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { Select as C, PageIntro as S, TextInput as T, useCare as _, getArticle as a, Disclaimer as b, checkupKinds as c, formatFaShort as d, orderedSymptoms as f, upcomingCheckups as g, todayISO as h, articles as i, faNum as l, safeTel as m, Route as n, cancerLabel as o, relativeDay as p, LevelChip as r, cancerOptions as s, router_exports as t, formatFa as u, Button as v, TextArea as w, Field as x, Card as y };
