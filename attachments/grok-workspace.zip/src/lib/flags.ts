import type { Symptom } from "@/lib/store";

export type Level = "urgent" | "soon" | "steady" | "empty";

export type Assessment = {
  level: Level;
  title: string;
  reasons: string[];
};

const copy: Record<Level, string> = {
  urgent: "امروز با تیم درمان تماس بگیرید",
  soon: "برای ویزیت نزدیک آماده شود",
  steady: "در محدودهٔ پیگیری معمول این ثبت",
  empty: "هنوز حالی ثبت نشده است",
};

export function assessSymptom(symptom: Symptom): Assessment {
  const urgent: string[] = [];
  if (symptom.fever) {
    urgent.push(
      "تب علامت خورده است. در بسیاری از برنامه‌های شیمی‌درمانی، تب دلیل تماس همان روز است؛ آستانهٔ دقیق را از تیم خودتان بپرسید.",
    );
  }
  if (symptom.breath) urgent.push("تنگی نفس یا سختی تنفس ثبت شده است.");
  if (symptom.bleeding) urgent.push("خونریزی غیرمعمول ثبت شده است.");
  if (symptom.vomiting) urgent.push("استفراغ شدید یا مهارنشده ثبت شده است.");
  if (symptom.confusion) urgent.push("گیجی، غش یا کاهش هوشیاری ثبت شده است.");
  if (symptom.pain >= 8) urgent.push("شدت درد ۸ یا بالاتر است.");
  if (urgent.length) return { level: "urgent", title: copy.urgent, reasons: urgent };

  const soon: string[] = [];
  if (symptom.pain >= 5) {
    soon.push("درد قابل‌توجه است. اگر رو به افزایش باشد زودتر از نوبت خبر دهید.");
  }
  if (symptom.nausea >= 7) soon.push("تهوع بالا ثبت شده است.");
  if (symptom.fatigue >= 8) soon.push("خستگی خیلی شدید ثبت شده است.");
  if (symptom.appetite <= 2) soon.push("اشتها خیلی کم شده است.");
  if (symptom.mood <= 2) {
    soon.push("حال روحی خیلی پایین است. حمایت روانی بخشی از درمان است، نه حاشیهٔ آن.");
  }
  if (symptom.weight === "down") {
    soon.push("کاهش وزن علامت خورده است. اگر عدد کیلو را دارید، همان را به پزشک بگویید.");
  }
  if (soon.length) return { level: "soon", title: copy.soon, reasons: soon };

  return {
    level: "steady",
    title: copy.steady,
    reasons: [
      "در این ثبت، مورد فوری‌ای که خودتان علامت زده باشید دیده نمی‌شود. این به معنی بی‌خطر بودن قطعی نیست.",
    ],
  };
}

export function latestAssessment(symptoms: Symptom[]): Assessment {
  if (!symptoms.length) {
    return {
      level: "empty",
      title: copy.empty,
      reasons: ["با ثبت حال امروز، قواعد هشدار چیزی برای گفتن پیدا می‌کنند."],
    };
  }
  const latest = [...symptoms].sort((a, b) => b.date.localeCompare(a.date))[0];
  return assessSymptom(latest);
}

export function trendNote(symptoms: Symptom[]) {
  if (symptoms.length < 2) return null;
  const ordered = [...symptoms].sort((a, b) => b.date.localeCompare(a.date));
  const [latest, previous] = ordered;
  if (!latest || !previous || latest.date === previous.date) return null;
  if (latest.pain - previous.pain >= 2) {
    return "درد نسبت به ثبت قبلی دست‌کم دو درجه بیشتر شده است.";
  }
  if (previous.pain - latest.pain >= 2) {
    return "درد نسبت به ثبت قبلی کمتر شده است.";
  }
  return null;
}
