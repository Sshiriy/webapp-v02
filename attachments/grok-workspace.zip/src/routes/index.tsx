import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, BookOpen, ClipboardList, ShieldCheck } from "lucide-react";
import { Disclaimer, Card } from "@/components/ui";
import { LevelChip } from "@/components/shell";
import { latestAssessment, trendNote } from "@/lib/flags";
import { formatFa, relativeDay, safeTel } from "@/lib/format";
import { cancerLabel, upcomingCheckups, useCare } from "@/lib/store";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "همدم | بیمارستان آیت‌الله رئیسی" }] }),
  component: Home,
});

const paths = [
  { title: "آموزش", text: "شش سرطان شایع طرح، به علاوهٔ واژه‌نامهٔ درمان و تب.", to: "/learn" },
  { title: "پیگیری", text: "درد، خستگی، تب و تقویم آزمایش و تزریق.", to: "/track" },
  { title: "حمایت", text: "مسیر مددکاری و حمایت روانی، بدون شمارهٔ ساختگی.", to: "/support" },
] as const;

function Home() {
  const profile = useCare((state) => state.profile);
  if (!profile.onboarded) return <Landing />;
  return <Dashboard />;
}

function Landing() {
  const loadDemo = useCare((state) => state.loadDemo);
  return (
    <div className="grid gap-8">
      <Disclaimer />
      <section className="grid items-end gap-8 lg:grid-cols-[1.4fr_0.8fr]">
        <div>
          <p className="text-sm font-medium text-copper">مرکز رشد فناوری سلامت · نسخهٔ اول</p>
          <h1 className="mt-3 max-w-xl text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl">
            همراه درمان، برای روزهایی که بین دو ویزیت می‌گذرد.
          </h1>
          <p className="mt-4 max-w-xl text-lg leading-8 text-muted">
            همدم برای بیماران بیمارستان آیت‌الله رئیسی ساخته شده تا آموزش درمان، دفتر حال، نوبت‌ها و
            سؤال‌های پیش از ویزیت یک‌جا بماند. تشخیص نمی‌دهد و جواب آزمایش را تفسیر نمی‌کند.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link
              to="/file"
              className="inline-flex min-h-11 items-center rounded-xl bg-cypress px-4 text-sm font-semibold text-paper"
            >
              ساخت پرونده روی این دستگاه
            </Link>
            <button
              type="button"
              onClick={loadDemo}
              className="inline-flex min-h-11 items-center rounded-xl border border-line bg-surface px-4 text-sm font-semibold"
            >
              دیدن با نمونهٔ نمایشی
            </button>
          </div>
        </div>
        <Card className="bg-cypress text-paper">
          <p className="text-sm text-foam">امروز چه کار می‌کند</p>
          <ul className="mt-4 grid gap-3 text-sm leading-6">
            <li>آموزش محافظه‌کارانه دربارهٔ مسیر درمان، نه کپی دستورالعمل‌های دارای مجوز.</li>
            <li>ثبت حال و قاعدهٔ شفاف «کی زنگ بزنید»؛ دلیلش را هم نشان می‌دهد.</li>
            <li>فرم پیش از ویزیت که می‌شود برای پزشک خواند.</li>
            <li>همراه هوشمند آموزشی، با ممنوعیت صریح تشخیص.</li>
          </ul>
        </Card>
      </section>

      <section className="grid gap-3 sm:grid-cols-3">
        {paths.map((item) => (
          <Link key={item.to} to={item.to} className="rounded-card border border-line bg-surface p-5">
            <h2 className="text-lg font-bold">{item.title}</h2>
            <p className="mt-2 text-sm leading-6 text-muted">{item.text}</p>
          </Link>
        ))}
      </section>

      <Card className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <ShieldCheck className="size-6 shrink-0 text-cypress" strokeWidth={1.75} />
        <p className="text-sm leading-7 text-muted">
          شبکهٔ عصبی تشخیص سرطان، پیش‌بینی متاستاز و اتصال هولتر در این نسخه عمداً نیست. دلیل بالینی‌اش
          را در محدودهٔ نسخه بخوانید.
        </p>
        <Link to="/scope" className="text-sm font-semibold text-cypress sm:ms-auto">
          محدودهٔ نسخه
        </Link>
      </Card>
    </div>
  );
}

function Dashboard() {
  const profile = useCare((state) => state.profile);
  const symptoms = useCare((state) => state.symptoms);
  const checkups = useCare((state) => state.checkups);
  const clearAll = useCare((state) => state.clearAll);
  const assessment = latestAssessment(symptoms);
  const trend = trendNote(symptoms);
  const next = upcomingCheckups(checkups)[0];
  const tel = safeTel(profile.clinicPhone);
  const latest = [...symptoms].sort((a, b) => b.date.localeCompare(a.date))[0];

  return (
    <div className="grid gap-6">
      <Disclaimer />
      {profile.demo ? (
        <p className="text-sm leading-6 text-copper">
          این پرونده نمونهٔ نمایشی و ساختگی است.{" "}
          <button type="button" onClick={clearAll} className="font-semibold underline">
            پاک کردن و شروع واقعی
          </button>
        </p>
      ) : null}

      <section className="grid gap-4 lg:grid-cols-[1.3fr_0.7fr]">
        <Card>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <p className="text-sm text-muted">پروندهٔ این دستگاه</p>
              <h1 className="mt-1 text-3xl font-extrabold tracking-tight">{profile.name || "بدون نام"}</h1>
              <p className="mt-2 text-sm text-muted">
                {cancerLabel(profile)}
                {profile.city ? ` · ${profile.city}` : ""}
                {profile.doctor ? ` · ${profile.doctor}` : ""}
              </p>
            </div>
            <LevelChip level={assessment.level} />
          </div>
          <h2 className="mt-6 text-xl font-bold">{assessment.title}</h2>
          <ul className="mt-3 grid gap-2 text-sm leading-6 text-muted">
            {assessment.reasons.map((reason) => (
              <li key={reason}>{reason}</li>
            ))}
          </ul>
          {trend ? <p className="mt-3 text-sm font-medium text-cypress">{trend}</p> : null}
          {assessment.level === "urgent" ? (
            <div className="mt-4">
              {tel ? (
                <a
                  href={tel}
                  className="inline-flex min-h-11 items-center rounded-xl bg-copper px-4 text-sm font-semibold text-paper"
                >
                  تماس با شماره‌ای که خودتان ذخیره کرده‌اید
                </a>
              ) : (
                <Link to="/file" className="text-sm font-semibold text-copper">
                  شمارهٔ درمانگاه را در پرونده بنویسید تا دکمهٔ تماس فعال شود
                </Link>
              )}
            </div>
          ) : null}
        </Card>

        <Card className="flex flex-col">
          <p className="text-sm text-muted">نوبت پیش رو</p>
          {next ? (
            <>
              <p className="mt-3 text-2xl font-extrabold tabular-nums">{relativeDay(next.date)}</p>
              <p className="mt-1 font-medium">{next.title}</p>
              <p className="text-sm text-muted">
                {formatFa(next.date)}
                {next.place ? ` · ${next.place}` : ""}
              </p>
            </>
          ) : (
            <p className="mt-3 leading-7 text-muted">نوبت آینده‌ای در تقویم نیست.</p>
          )}
          <Link to="/track" className="mt-auto pt-4 text-sm font-semibold text-cypress">
            دفتر پیگیری
          </Link>
        </Card>
      </section>

      <section className="grid gap-3 sm:grid-cols-3">
        <Link to="/track" className="rounded-card border border-line bg-surface p-4">
          <ClipboardList className="size-5 text-cypress" strokeWidth={1.75} />
          <h2 className="mt-3 font-bold">ثبت حال امروز</h2>
          <p className="mt-1 text-sm text-muted">
            {latest ? `آخرین ثبت ${formatFa(latest.date)}` : "هنوز ثبتی نیست"}
          </p>
        </Link>
        <Link to="/visit" className="rounded-card border border-line bg-surface p-4">
          <BookOpen className="size-5 text-cypress" strokeWidth={1.75} />
          <h2 className="mt-3 font-bold">پیش از ویزیت</h2>
          <p className="mt-1 text-sm text-muted">سؤال‌ها را قبل از اتاق پزشک بنویسید.</p>
        </Link>
        <Link to="/companion" className="rounded-card border border-line bg-surface p-4">
          <ArrowLeft className="size-5 text-cypress" strokeWidth={1.75} />
          <h2 className="mt-3 font-bold">پرسش آموزشی</h2>
          <p className="mt-1 text-sm text-muted">توضیح واژهٔ درمان، نه نظر تشخیصی.</p>
        </Link>
      </section>
    </div>
  );
}
